ILLUSION FIGHT — PRESS KIT (ENGLISH)
illusionfight.com · lutasdeilusao@gmail.com

======================================================================
1. IN ONE SENTENCE
======================================================================
Illusion Fight is a free action universe created by Isaias Leal: books,
a webtoon, games and an original soundtrack, all connected at
illusionfight.com, in English, Portuguese and Spanish.

SHORT DESCRIPTION (ready to paste)
Illusion Fight is a free action universe created by Isaias Leal: books,
a webtoon, games and an original soundtrack, all connected at
illusionfight.com, in English, Portuguese and Spanish. The demo is on
Steam and the universe is part of Steam Next Fest, October 19–26.
Season 1 launches on November 15, 2026.

======================================================================
2. FACT SHEET
======================================================================
Name ........... Illusion Fight (Lutas de Ilusão)
Creator ........ Isaias Leal
Format ......... Books, webtoon (WEB SHARD), games and original soundtrack
Games .......... LDI Gangues, Lendas do LDI, LDI Top Trumps (online) and MiniGames
Languages ...... English, Portuguese and Spanish
Price .......... Free, with an optional subscription
Steam Next Fest  October 19–26, 2026
Launch ......... Season 1 on November 15, 2026
Website ........ https://illusionfight.com
Steam .......... https://store.steampowered.com/app/1876210
Steam demo ..... https://store.steampowered.com/app/5188520

======================================================================
3. THE UNIVERSE: ILLUSION FIGHT
======================================================================
In the city of Marélia, in Bravara, teenagers from all over the world
climb a global ranking by fighting in the LDI, a combat simulator. The
fight is virtual. The pain is real. Kim, a 17-year-old who sells candy on
buses and attends Elite Academy on a scholarship, fights his first LDI
match and it goes viral worldwide — not because he won, but because of
what came out of him before he did. Kim carries the Primordial Blood of
the Xakaxi, an Indigenous people who sealed away a corrupted spirit 500
years ago. That spirit, now called David Kronos, wants Kim. Whatever the
cost.

Themes: friendship, poverty and dignity, the family you choose,
Indigenous ancestry, fighting as a language.

======================================================================
4. THE WORKS
======================================================================
ILLUSION FIGHT (book — main storyline)
The story of Kim, Jack and Nina. Weekly chapters starting with Season 1.
Read at illusionfight.com/historias/lutas-de-ilusao

WEB SHARD (webtoon)
The webtoon of the Illusion Fight universe, vertical scroll, in English,
Portuguese and Spanish. illusionfight.com/webtoon

ILLUSION TALES (short stories, free for everyone)
The characters' pasts, each told in first person.
  01 · Sonata of a Fight — Ryan's grey life at Elite Academy: his
       father, the bully Arnold, and the day he decided to end it all —
       until he bumped into the only two guys in school who have color.
  02 · Alan, the Champion — How Alan became the Crime King of Marélia,
       from the murder he witnessed at three to the day a street kid
       refused to leave his turf.
  03 · Kim and Jack's Band — Why Jack won't stop saying they have a
       band. Told by Kim, as reluctantly as humanly possible.
  04 · I Am Nina — The mother she doesn't remember, the seven years of
       poverty her father chose for her, and the talk that explained it.
  05 · Because That's How Jack Chose It — Parents who loved him and
       couldn't raise him, the streets at five, the delivery business he
       built from nothing, and a secret nobody ever asked about.
  06 · Innocent Until Proven Otherwise — Freddy's party, Jasmine, a cake
       and a knee to the face that belonged to nobody. Told by Jack, his
       way.
  07 · The Chains — Kim and Jack, covering for each other: the first
       fight against the Champion and the night a biker club took Helena
       over a debt.
illusionfight.com/historias/contos

THE SHADOW WORLD (book — Discovery Saga · Book 1, horror)
Minus is nine years old and has already lost everything three times. The
spiral burned into his shoulder draws the shadows — creatures that feed
on pain — and an Illuminated One who has hated him since the cradle.
Alone on the streets of Brasília, he learns to turn his own fear into a
weapon. Available on Amazon: https://www.amazon.com.br/dp/B0GF4N2V9G

SEA OF ASHES (book — Arc I · Escape, dark fantasy, unreleased)
In an archipelago where fuel is made from the crystallized memory of
dead gods, seventeen-year-old Elizabeth Thoss is married off to a
commander of the Admiralty. She has no proof of what he did to his
previous wives — she has something better: years of invisibility and a
memory that forgets nothing.

======================================================================
5. THE GAMES (all free, in the browser)
======================================================================
LDI GANGUES — Build a gang and take over the neighborhoods of Marélia,
with mob brawls, a fight club and a boss in every territory.
illusionfight.com/games/ldi-gangues

LENDAS DO LDI (LDI Legends) — A story game. You choose your Vein, and
the way you fight changes the way the story is told.
illusionfight.com/games/ldi

LDI TOP TRUMPS — Collect fighters, beat the AI and play online against
other people. illusionfight.com/games/toptrumps

ILLUSION FIGHT — SEASON 1 DEMO (Steam) — Part of Steam Next Fest,
October 19–26. Wishlisting helps the project a lot.

RADIO NINA — The universe's original soundtrack, playing on the site.
illusionfight.com/musicas

======================================================================
6. CHARACTERS
======================================================================
KIM (Joaquim Leal Reis), 17 — Xakaxi descendant. Has sold candy on buses
  since he was twelve and attends Elite Academy on a scholarship. Carries
  something ancestral he never asked for and can't control.
  "I don't beg anyone. Ever."
JACK, 17 — Green dreads, phone always in hand, laughs at everything and
  is more dangerous than he looks. Kim's best friend since they were
  twelve. Fights with the cane Vitória.
NINA — Arrived unannounced. The katana Angel, Muay Thai and a past she
  doesn't explain. Beat Kim in their first serious fight.
RYAN — Elite Academy student. Has everything, except a morning that
  doesn't hurt. Lead of the story Sonata of a Fight.
ALAN, THE CHAMPION, 24 — Became the Crime King of Marélia at eighteen.
  The rival who taught them some fights can't be won, only survived.
HELENA — Kim's adoptive mother. She was twelve when she ran away with
  him in her arms.
SHAMAN YAWANARI — Immortal Xakaxi shaman, guardian of the seal for 500
  years. Ancestral wisdom sharing space with pop culture.
DAVID KRONOS — The current name of Voa, a corrupted ancestral spirit who
  has waited centuries for the Primordial Blood.
SHUNTARO CHIRASU — World #998. Traveled nine hours from Azuma just to
  fight Kim.
LISA — Global top 500 and international pop star. Sings, dances, fights.

======================================================================
7. THE AUTHOR: ISAIAS LEAL
======================================================================
Isaias started working at 13, selling candy on buses in Brazil —
without knowing it, living the story he would one day write. At 17, in a
history class, he noticed nobody told the story of Brazil's Indigenous
peoples before the "discovery". That's where Illusion Fight was born: he
wrote it in Word, printed it at school and handed out the pages, and
every week his classmates demanded the next chapter.

At 30, after ten years as a civil servant, he turned his life upside
down: he studied for a scholarship, joined the games industry as an
intern and specialized in porting games to Nintendo, Xbox and
PlayStation. He has worked on international projects, including Five
Nights at Freddy's and a release in the God of War universe. Today, at
40, he is publishing the universe he has been building since he was 17 —
books, webtoon, games and soundtrack, made independently.

======================================================================
8. CONTENT IDEAS
======================================================================
- Three universes, one author: compare the tone of Illusion Fight
  (action), The Shadow World (horror) and Sea of Ashes (dark fantasy).
- A live commented reading of chapter 1.
- From book to webtoon: the same scene in prose and in WEB SHARD.
- From zero to neighborhood boss: an LDI Gangues run.
- Challenge your audience in online Top Trumps.
- A Brazilian universe published in three languages from day one.
- Add the demo to your Steam Next Fest coverage (Oct 19–26).

======================================================================
9. USAGE RULES
======================================================================
- The art in this kit is cleared for your content about Illusion Fight
  (videos, streams, posts, articles, thumbnails).
- You can criticize it. Criticism is content. Nobody approves anything.
- Excerpts, screenshots and up to 3 pages per post are fine.
- Don't republish complete content: a full chapter, a full webtoon
  episode or the original files.
- Please add illusionfight.com to your description if you can.

======================================================================
10. WHAT'S IN THIS KIT
======================================================================
01-logos ........ Official logo in English, Portuguese and Spanish (PNG)
02-banners ...... Promotional art (book, WEB SHARD, games, music, store)
03-capas ........ Covers: Illusion Fight, WEB SHARD, Illusion Tales,
                  The Shadow World, Sea of Ashes
04-contos ....... A cover for each Illusion Tale
05-personagens .. Character sheets (Kim, Jack, Nina, Ryan)

Need specific art, an interview or more information?
Write to lutasdeilusao@gmail.com
